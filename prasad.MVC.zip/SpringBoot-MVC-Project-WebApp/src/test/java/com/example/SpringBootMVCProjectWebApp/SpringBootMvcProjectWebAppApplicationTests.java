package com.example.SpringBootMVCProjectWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMvcProjectWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
